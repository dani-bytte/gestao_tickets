//const { loggers } = require("winston");

// public/js/fetchDashboardData.js
document.addEventListener('DOMContentLoaded', () => {
  fetch('/admin/dashboard-data', {
    credentials: 'include' // Inclui os cookies na requisição
  })
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(data => {
      
      document.getElementById('totalUsers').textContent = data.totalUsers;
      document.getElementById('totalTickets').textContent = data.totalTickets;
      document.getElementById('pendingTickets').textContent = data.pendingTickets;
      document.getElementById('completedTickets').textContent = data.completedTickets;
      document.getElementById('dueTickets').textContent = data.dueTickets;
      document.getElementById('todayTickets').textContent = data.todayTickets;
      document.getElementById('upcomingTickets').textContent = data.upcomingTickets;

      ticketStatusChart.data.datasets[0].data = [
        data.totalTickets,          // Em Aberto
        data.pendingTickets,        // Pendente
        data.completedTickets,      // Finalizados não pagos
        data.dueTickets             // Vencidos
      ];
      ticketStatusChart.update();
    })
    .catch(error => {
      console.error('Erro ao buscar dados da dashboard:', error);
    });

  // Função para configurar os modais dos cartões
  function setupCardModal(cardId, endpoint, title) {
    const card = document.querySelector(`#${cardId}`).parentElement;
    card.style.cursor = 'pointer';
    
    card.addEventListener('click', async () => {
      try {
        const response = await fetch(`/admin/${endpoint}`, {
          credentials: 'include'
        });
        if (!response.ok) {
          throw new Error('Network response was not ok');
        }
        const tickets = await response.json();
        
        const modalContent = document.getElementById('overdueTicketsList');
        if (tickets && tickets.length > 0) {
          modalContent.innerHTML = `
            <h3>${title}</h3>
            ${tickets.map(ticket => `
              <div class="overdue-ticket-item">
                <p><strong>Ticket:</strong> ${ticket.ticket}</p>
                <p><strong>Usuário:</strong> ${ticket.createdBy.username}</p>
                <p><strong>Status:</strong> ${ticket.status}</p>
                <p><strong>Vencimento:</strong> ${new Date(ticket.endDate)
                  .toLocaleDateString('pt-BR', {
                    timeZone: 'America/Sao_Paulo',
                    day: '2-digit',
                    month: '2-digit',
                    year: 'numeric'
                  })}</p>
              </div>
            `).join('')}
          `;
        } else {
          modalContent.innerHTML = '<div class="no-tickets-message">Nenhum ticket encontrado</div>';
        }

        const modal = document.getElementById('overdueTicketsModal');
        modal.style.display = 'block';
      } catch (error) {
        console.error('Erro ao buscar os tickets:', error);
      }
    });
  }

  // Configurar os modais para os cartões
  setupCardModal('todayTickets', 'today-tickets', 'Tickets que Vencem Hoje');
  setupCardModal('upcomingTickets', 'upcoming-tickets', 'Tickets dos Próximos 2 Dias');
  setupCardModal('dueTickets', 'overdue-tickets', 'Tickets Vencidos');

  // Handler para fechar o modal
  const closeOverdueModal = document.getElementById('closeOverdueModal');
  closeOverdueModal.addEventListener('click', () => {
    const modal = document.getElementById('overdueTicketsModal');
    modal.style.display = 'none';
  });

  // Fechar modal ao clicar fora
  window.addEventListener('click', (event) => {
    const modal = document.getElementById('overdueTicketsModal');
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  });

  // Fechar modal com a tecla ESC
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      const modal = document.getElementById('overdueTicketsModal');
      modal.style.display = 'none';
    }
  });

  // Configuração do gráfico
  const ctx = document.getElementById('ticketStatusChart').getContext('2d');

  const ticketStatusChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['Em Aberto', 'Pendente', 'Finalizados não pagos', 'Vencidos'],
      datasets: [{
        label: 'Status dos Tickets',
        data: [], // Deixe vazio, será atualizado dinamicamente
        backgroundColor: [
          'rgba(54, 162, 235, 0.6)',
          'rgba(255, 206, 86, 0.6)',
          'rgba(75, 192, 192, 0.6)',
          'rgba(255, 99, 132, 0.6)'
        ],
        borderColor: [
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(255, 99, 132, 1)'
        ],
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
});