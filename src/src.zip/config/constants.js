// config/constants.js
module.exports = {
    ROLES: {
      ADMIN: 'admin',
      FINANCEIRO: 'financeiro',
      USER: 'user'
    },
    STATUS: {
      PENDENTE: 'pendente',
      FINALIZADO: 'finalizado'
    },
    PAYMENT_STATUS: {
      PENDENTE: 'pendente',
      COMPLETO: 'completo'
    }
  };